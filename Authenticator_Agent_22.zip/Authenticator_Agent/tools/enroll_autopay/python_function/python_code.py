def enroll_autopay(account_id: str, platform_cd: str) -> dict:
    """Demo stub: enrolls an account in autopay."""

    if not account_id:
        return {
            "status": "error",
            "autopay_announcement": None,
            "error": "Account ID is required"
        }

    if platform_cd not in {"CB", "LV", "EM"}:
        return {
            "status": "error",
            "autopay_announcement": None,
            "error": "platform_cd must be one of CB, LV, EM"
        }

    return {
        "status": "success",
        "autopay_announcement": "You are now enrolled in autopay for your premium billing.",
        "error": None
    }
