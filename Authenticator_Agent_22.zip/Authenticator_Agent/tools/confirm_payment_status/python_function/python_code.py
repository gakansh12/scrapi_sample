def confirm_payment_status(account_id: str, platform_cd: str, payment_confirm_window: str) -> dict:
    """Demo stub: confirms payment status for a given time window."""

    if not account_id:
        return {
            "status": "error",
            "confirmation_announcement": None,
            "error": "Account ID is required"
        }

    if platform_cd not in {"CB", "LV", "EM"}:
        return {
            "status": "error",
            "confirmation_announcement": None,
            "error": "platform_cd must be one of CB, LV, EM"
        }

    if payment_confirm_window not in {"today", "earlier"}:
        return {
            "status": "error",
            "confirmation_announcement": None,
            "error": "payment_confirm_window must be today or earlier"
        }

    if payment_confirm_window == "today":
        msg = "Your most recent payment is still processing. Please check again later."
    else:
        msg = "Your most recent payment appears to have posted successfully."

    return {
        "status": "success",
        "confirmation_announcement": msg,
        "error": None
    }
