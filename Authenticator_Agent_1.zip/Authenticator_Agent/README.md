# Authenticator Agent — Case-by-case Procedure

This folder contains a multi-agent voice/chat application. The behavior is primarily defined in each agent’s `instruction.txt` and wired together by routing rules.

## Quick start (what runs first)

**Root agent is the entrypoint** (see `app.json` → `rootAgent`). The Root agent enforces this strict sequence for every conversation:

1. Delegate to **AuthAgent** first (no other work until authentication is confirmed).
2. After authentication: ask the user, **“What is the reason for your call today?”**
3. Delegate to **humana-intent-repro-agent-1** to identify the user’s intent.
4. Route to the correct downstream agent based on the identified intent.

## How to “go through each case” (recommended walkthrough order)

When validating or demoing this agent, walk the cases in the order below. Each case is designed to exercise a distinct branch in the orchestration.

### Case 1 — Authentication success
**Goal:** Confirm the system gates all downstream behavior behind authentication.

Procedure:
1. Start a new session and let the Root agent delegate to **AuthAgent**.
2. Provide a valid `account_id`.
3. Provide a date of birth that can be converted to `DD/MM/YYYY` and passes `verify_caller_dob`.

Expected behavior:
- AuthAgent sets:
  - `is_authenticated = true`
  - `caller_name = <name from tool>`
- AuthAgent says: **“Thank you, {caller_name}. I've verified your identity successfully.”**
- Control returns to the Root agent.

### Case 2 — Authentication failure then retry
**Goal:** Validate retry logic.

Procedure:
1. Provide an invalid `account_id` and/or invalid DOB.
2. Confirm the agent says: **“I'm sorry, I couldn't verify those details. Let's try again.”**
3. Provide valid details on the second attempt.

Expected behavior:
- Authentication is re-attempted from STEP 1.
- On second attempt success, proceed as in Case 1.

### Case 3 — Authentication failure twice (session ends)
**Goal:** Validate lockout behavior.

Procedure:
1. Provide invalid details twice.

Expected behavior:
- AuthAgent says:
  - **“I'm sorry, I was unable to verify your identity after multiple attempts. For your security, I cannot continue this call. Please contact support.”**
- Session ends.

---

## Post-auth: intent identification “cases”

After Case 1 (authentication success), the Root agent collects a reason and delegates to **humana-intent-repro-agent-1**.

### Case 4 — Intent match found
**Goal:** Validate dictionary-based matching and transfer.

Procedure:
1. After Root asks for the reason, provide an utterance that matches a `semantic_tag` in the dictionary returned by `intent_mapping_getTagDictionary`.

Expected behavior (humana-intent-repro-agent-1):
1. Silently calls `intent_mapping_getTagDictionary` (mandatory, every input).
2. If match is **not** a vague tag, sets:
   - `Sub-intent = <semantic_tag>`
   - `fallback_counter = 0`
3. Speaks exactly:
   - **“Sure, I can help with [identified_semantic_tag].”**
4. Calls **Transfer_agent**.

**Note (repro environment):** `Transfer_agent` is a stub that outputs `STUB_TRANSFER` and stops.

### Case 5 — Intent no-match, first time
**Goal:** Validate fallback prompt and counter.

Procedure:
1. Provide an utterance that does not match any dictionary entry.

Expected behavior:
- Speaks exactly:
  - **“I didn't quite get that. How can I help? For example, you can say 'check my benefits', 'claim status', or 'billing question'.”**
- Sets `fallback_counter = 1`.

### Case 6 — Intent no-match, second time (transfer)
**Goal:** Validate MAXERROR + transfer.

Procedure:
1. Trigger Case 5 (no-match) to set `fallback_counter = 1`.
2. Provide another no-match utterance.

Expected behavior:
- Sets `Sub-intent = MAXERROR`.
- Calls **Transfer_agent** (stub prints `STUB_TRANSFER`).

---

## Billing domain: Premium Billing Router “cases”

If your intent routing sends the user into billing, the billing hub agent is **Premium_Billing_Router**.

### Case 7 — Billing: check balance
Procedure:
1. At the billing menu, say something like “Check my balance”.

Expected behavior (Premium_Billing_Router):
1. Silently sets:
   - `billing_domain = true`
   - `current_billing_intent = check-balance`
   - `fallback_counter = 0`
2. Routes to **Play_Balance_Agent**.

Expected behavior (Play_Balance_Agent):
1. Calls `record_user_intent`.
2. Ensures `account_id` and `platform_cd` exist (asks user if missing).
3. Calls `check_balance(account_id, platform_cd)`.
4. If success: reads `balance_announcement` from the tool response (no guessing).

### Case 8 — Billing: view payment history
Procedure:
1. At the billing menu, say “Payment history”.

Expected behavior (Premium_Billing_Router):
- Sets context (as above) with `current_billing_intent = payment-history`.
- Routes to **Payment_History_Agent**.

Expected behavior (Payment_History_Agent):
- **Platform branch** (uses `platform_cd`):
  - If `platform_cd = CB` (CBIS): plays the combined announcement exactly:
    - “To view your past payments, please visit our website at humana one members dot com. What do you want to do next? You can say hear balance, make a payment, add or update payment or something else. If you are done with billing and payments, say All Set”
  - If `platform_cd = LV` or `EM` (Non-CBIS):
    1. Calls `call_payment_history_details`.
    2. If tool error **or** `number_of_payments_returned > 10` **or** required fields are missing:
       - Silently sets `exit_tag = check-on_payment`
       - Immediately returns control to **Premium_Billing_Router**.
    3. Otherwise reads `payment_announcement` **exactly as returned**.
    4. If `number_of_payments_returned > 0`, asks once:
       - “Do you want me to repeat the payment history?”
       - If yes: repeats the same announcement **exactly once**.
    5. Proceeds to wrap-up menu and records the mapped intent.

**Payment History scope-limit “case”:**
- If the user asks for specific historical ranges (e.g., “last 6 months”, “December payments”), Payment_History_Agent must set `exit_tag = check-on_payment` and return to Premium_Billing_Router.

### Case 9 — Billing: add payment method
Procedure:
1. At the billing menu, say “Make a payment”.

Expected behavior:
- Premium_Billing_Router routes to **Add_Payment_Agent**.

Key branches (Add_Payment_Agent):
- **Determine payment method**:
  - Calls `evaluate_and_route_payment_methods`.
  - If user must choose: asks “Got it. Do you want to add a new card or bank account to make this payment?”
- **ACH flow**: collects routing number (9 digits) then account number (9–12 digits).
- **Card flow**: collects card number, then expiration date (converts to `MMYY` and calls `format_and_route_expiry_date`).
- **Submission**:
  - For cards: calls `call_generate_dv_token` (must succeed before submit).
  - Calls `call_process_payment_submit`.
  - On success: announces success and records intent; then offers wrap-up menu.

**Error/No-input “case”:**
- On any invalid input or silence, Add_Payment_Agent calls `add_payment_interaction_handler` and plays the prompt returned (no custom retries).

### Case 10 — Billing: update payment method
Procedure:
1. At the billing menu, say “Update my payment method”.

Expected behavior:
- Premium_Billing_Router routes to **Update_Payment_Agent**.

Key scenario branches (Update_Payment_Agent):
- `initial_scenario = NO_METHODS` → routes to Add_Payment_Agent when user chooses to add.
- `initial_scenario = ONE_METHOD_CARD` → update vs replace vs remove paths.
- `initial_scenario = ONE_METHOD_ACH` → update vs replace vs remove paths.
- `initial_scenario = MULTIPLE_METHODS` → confirm recent method, or collect last 4 digits, possibly full number, then disambiguate card vs bank if needed.

**Invalid/off-topic “case”:**
- For invalid or off-topic replies, Update_Payment_Agent must immediately call `record_user_intent` with the appropriate failure intent and must not speak its own retry text.

### Case 11 — Billing: all set
Procedure:
1. At billing menu, say “All set”.

Expected behavior:
- Premium_Billing_Router says: “Thank you for using our billing services. Your call will end now.”
- Calls `record_user_intent(intent="all_set")`.

### Case 12 — Billing: something else / escalation
Procedure:
1. Provide a billing request that does not map to the supported billing intents.

Expected behavior:
- Premium_Billing_Router says: “I can help with that through our support team.”
- Calls `record_user_intent(intent="billing_escalation")`.

---

## Reference map (where to look)

- Root orchestration: `agents/Root_agent/instruction.txt`
- Authentication: `agents/AuthAgent/instruction.txt`
- Intent mapping + transfer: `agents/humana-intent-repro-agent-1/instruction.txt`, `agents/Transfer_agent/instruction.txt`
- Billing hub router: `agents/Premium_Billing_Router/instruction.txt`
- Billing subagents:
  - Balance: `agents/Play_Balance_Agent/instruction.txt`
  - Payment history: `agents/Payment_History_Agent/instruction.txt`
  - Add payment: `agents/Add_Payment_Agent/instruction.txt`
  - Update payment: `agents/Update_Payment_Agent/instruction.txt`
